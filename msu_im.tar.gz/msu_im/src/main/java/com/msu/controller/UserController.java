package com.msu.controller;

import com.msu.response.*;
import com.msu.rjson.ReqUser;
import com.msu.rjson.RespCode;
import com.msu.rjson.RespEntity;
import com.msu.pojo.User;
import com.msu.services.UserServices;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import sun.rmi.runtime.Log;

import java.util.ArrayList;

@CrossOrigin(origins = "*", maxAge = 3600)
@Service
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserServices userServices;

    @ResponseBody
    @RequestMapping("/getUser")
    public RespEntity getUserById() {

        ArrayList<User> users = userServices.selectByLikeUserName("");
        return new RespEntity(RespCode.SUCCESS, users);

    }


    @ResponseBody
    @RequestMapping(value = "/login")
    public RespEntity login(@RequestBody ReqUser reqUser) {
        User user ;
        user = userServices.getUserByUsername(reqUser.getUsername());
        if (user == null) {
            return new RespEntity(RespCode.WARN, null);
        }
        LoginRes loginRes = new LoginRes();
        UserInfo userInfo = new UserInfo();
        BeanUtils.copyProperties(user, userInfo);
        loginRes.setUserInfo(userInfo);
        if (!user.getPassword().equals(reqUser.getPassword())) {
            return new RespEntity(RespCode.WARN, loginRes);
        } else {
            return new RespEntity(RespCode.SUCCESS, loginRes);
        }
    }

    @ResponseBody
    @RequestMapping(value = "/register")
    //{username ; password}are required
    public RespEntity register(@RequestBody ReqUser request) {
        User user = new User();

        User tuser = userServices.getUserByUsername(request.getUsername());
        if (tuser != null)
            // if the username is already occupied, return fail
            return new RespEntity(RespCode.WARN, null);

        user.setUsername(request.getUsername());
        user.setPassword(request.getPassword());
        user.setCid("");
        user.setFaceImage("");
        user.setNickname("fker");
        user.setFaceImageBig("faker");
        user.setQrcode("nothing");

        User userResult = userServices.insertNewUser(user);
        return new RespEntity(RespCode.SUCCESS, null);
    }

}
