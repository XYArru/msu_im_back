package com.msu.controller;


import com.msu.pojo.FriendsRequest;
import com.msu.pojo.MyFriends;
import com.msu.pojo.User;
import com.msu.rjson.ReqFriend;
import com.msu.rjson.ReqUser;
import com.msu.rjson.RespCode;
import com.msu.rjson.RespEntity;
import com.msu.services.UserServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.Date;

@CrossOrigin(origins = "*", maxAge = 3600)
@Service
@RequestMapping("/friend")
public class FriendController {
    @Autowired
    UserServices userServices;

    @ResponseBody
    @RequestMapping(value = "/find")
    public RespEntity find(@RequestBody ReqUser reqUser){
        User user = new User();
        ArrayList<User> users = userServices.selectByLikeUserName(reqUser.getUsername());
        return new RespEntity(RespCode.SUCCESS, users);
    }

    @ResponseBody
    @RequestMapping(value = "/sendRequest")
    public RespEntity sendRequest(@RequestBody ReqFriend reqFriend){
        String sendUserId = userServices.getUserByUsername(reqFriend.getSendName()).getId();
        String acceptUserId = userServices.getUserByUsername(reqFriend.getAcceptName()).getId();
        FriendsRequest friendsRequest = userServices.getRequestBySendAndAcceptUser(acceptUserId,sendUserId);
        //首先判断是否已经是好友
        if(userServices.getMyFriendsByMeAndFriend(sendUserId,acceptUserId) != null){
            return new RespEntity(RespCode.WARN, "已经是好友");
        }
        //判断是否重复发送好友请求
        if(userServices.getRequestBySendAndAcceptUser(sendUserId,acceptUserId) != null){
            return new RespEntity(RespCode.WARN, "请勿重复发送请求");
        }
        //判断对方是否向自己发送好友请求，若是，则直接成为好友
        if(friendsRequest != null){
            MyFriends myFriends1 = new MyFriends();
            MyFriends myFriends2 = new MyFriends();
            myFriends1.setMyUserId(sendUserId);
            myFriends1.setMyFriendUserId(acceptUserId);
            myFriends2.setMyUserId(acceptUserId);
            myFriends2.setMyFriendUserId(sendUserId);
            userServices.insertNewFriend(myFriends1);
            userServices.insertNewFriend(myFriends2);
            userServices.deleteFriendsRequestById(friendsRequest.getId());
            return new RespEntity(RespCode.SUCCESS, "成为好友");
        }
        Date d=new Date();
        FriendsRequest friendsRequest1 = new FriendsRequest();
        friendsRequest1.setSendUserId(sendUserId);
        friendsRequest1.setAcceptUserId(acceptUserId);
        friendsRequest1.setRequestDateTime(d);
        FriendsRequest result = userServices.insertNewRequest(friendsRequest1);
        return new RespEntity(RespCode.SUCCESS, result);
    }

    @ResponseBody
    @RequestMapping(value = "/viewRequest")
    public RespEntity viewRequest(@RequestBody ReqUser reqUser){
        User user = userServices.getUserByUsername(reqUser.getUsername());
        ArrayList<FriendsRequest> friendsRequests = userServices.getRequestByAcceptUser(user.getId());
        return new RespEntity(RespCode.SUCCESS, friendsRequests);
    }

    @ResponseBody
    @RequestMapping(value = "/acceptRequest")
    public RespEntity acceptRequest(@RequestBody ReqFriend reqFriend){
        String sendUserId = userServices.getUserByUsername(reqFriend.getSendName()).getId();
        String acceptUserId = userServices.getUserByUsername(reqFriend.getAcceptName()).getId();
        FriendsRequest friendsRequest = userServices.getRequestBySendAndAcceptUser(sendUserId,acceptUserId);
        if(friendsRequest == null){
            return new RespEntity(RespCode.WARN);
        }
        MyFriends myFriends1 = new MyFriends();
        MyFriends myFriends2 = new MyFriends();
        myFriends1.setMyUserId(sendUserId);
        myFriends1.setMyFriendUserId(acceptUserId);
        myFriends2.setMyUserId(acceptUserId);
        myFriends2.setMyFriendUserId(sendUserId);
        userServices.insertNewFriend(myFriends1);
        userServices.insertNewFriend(myFriends2);
        userServices.deleteFriendsRequestById(friendsRequest.getId());
        return new RespEntity(RespCode.SUCCESS, "添加成功");
    }

    @ResponseBody
    @RequestMapping(value = "/refuseRequest")
    public RespEntity refuseRequest(@RequestBody ReqFriend reqFriend){
        String sendUserId = userServices.getUserByUsername(reqFriend.getSendName()).getId();
        String acceptUserId = userServices.getUserByUsername(reqFriend.getAcceptName()).getId();
        FriendsRequest friendsRequest = userServices.getRequestBySendAndAcceptUser(sendUserId,acceptUserId);
        if(friendsRequest == null){
            return new RespEntity(RespCode.WARN);
        }
        userServices.deleteFriendsRequestById(friendsRequest.getId());
        return new RespEntity(RespCode.SUCCESS, "已拒绝");
    }

    @ResponseBody
    @RequestMapping(value = "/viewMyFriends")
    public RespEntity viewMyFriends(@RequestBody ReqUser reqUser){
        User user = userServices.getUserByUsername(reqUser.getUsername());
        ArrayList<MyFriends> myFriends= userServices.getMyFriendsByMyId(user.getId());
        ArrayList<User> users = new ArrayList<>();
        for(int i = 0; i < myFriends.size(); i++){
            users.add(userServices.getUserById(myFriends.get(i).getMyFriendUserId()));
        }
        return new RespEntity(RespCode.SUCCESS, users);
    }

    @ResponseBody
    @RequestMapping(value = "/deleteMyFriends")
    public  RespEntity deleteMyFriends(@RequestBody ReqFriend reqFriend){
        String myId = userServices.getUserByUsername(reqFriend.getSendName()).getId();
        String friendId = userServices.getUserByUsername(reqFriend.getAcceptName()).getId();
        userServices.deleteMyFriendsByMeAndFriend(myId,friendId);
        userServices.deleteMyFriendsByMeAndFriend(friendId,myId);
        return new RespEntity(RespCode.SUCCESS, "删除完毕");
    }
}
