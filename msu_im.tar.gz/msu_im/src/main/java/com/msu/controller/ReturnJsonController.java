package com.msu.controller;

import com.msu.pojo.User;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;




//useless actually
@RestController
@RequestMapping("/t_user")
public class ReturnJsonController {

    @RequestMapping("/getUser")
    public User getUser(){
        User user = new User();
        user.setId("1");
        user.setUsername("wo");
        user.setPassword("111");
        return user;
    }
}
