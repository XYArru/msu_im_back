package com.msu.mapper;

import com.msu.pojo.MyFriends;

import java.util.ArrayList;

public interface MyFriendsMapper {
    int deleteByPrimaryKey(String id);

    int insert(MyFriends record);

    int insertSelective(MyFriends record);

    MyFriends selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(MyFriends record);

    int updateByPrimaryKey(MyFriends record);

    ArrayList<MyFriends> selectMyFriendsByMyId(String id);

    MyFriends selectByMeAndFriend(String myId, String friendId);

    int deleteByMeAndFriend(String myId, String friendId);
}