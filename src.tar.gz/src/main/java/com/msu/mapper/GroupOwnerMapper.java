package com.msu.mapper;

import com.msu.pojo.GroupOwner;

import java.util.ArrayList;

public interface GroupOwnerMapper {
    int deleteByPrimaryKey(String id);

    int insert(GroupOwner record);

    int insertSelective(GroupOwner record);

    GroupOwner selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(GroupOwner record);

    int updateByPrimaryKey(GroupOwner record);

    GroupOwner selectByGroupName(String groupName);

    ArrayList<GroupOwner> selectByLikeGroup(String groupName);

    ArrayList<GroupOwner> selectByUsername(String username);
}