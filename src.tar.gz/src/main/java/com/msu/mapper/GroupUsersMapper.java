package com.msu.mapper;

import com.msu.pojo.GroupOwner;
import com.msu.pojo.GroupUsers;

import java.util.ArrayList;

public interface GroupUsersMapper {
    int deleteByPrimaryKey(String id);

    int insert(GroupUsers record);

    int insertSelective(GroupUsers record);

    GroupUsers selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(GroupUsers record);

    int updateByPrimaryKey(GroupUsers record);

    ArrayList<GroupUsers> selectByGroupName(String groupName);

    GroupUsers selectByGroupNameAndUsername(String groupName, String username);

    ArrayList<GroupUsers> selectByUsername(String username);
}