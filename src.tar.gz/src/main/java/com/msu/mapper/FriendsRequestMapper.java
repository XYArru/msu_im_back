package com.msu.mapper;

import com.msu.pojo.FriendsRequest;

import java.util.ArrayList;

public interface FriendsRequestMapper {
    int deleteByPrimaryKey(String id);

    int insert(FriendsRequest record);

    int insertSelective(FriendsRequest record);

    FriendsRequest selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(FriendsRequest record);

    int updateByPrimaryKey(FriendsRequest record);

    ArrayList<FriendsRequest> selectByAcceptUser(String id);

    FriendsRequest selectBySendAndAcceptUser(String sendUser, String acceptUser);
}