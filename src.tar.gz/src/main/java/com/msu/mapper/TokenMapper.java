package com.msu.mapper;

import com.msu.pojo.Token;

public interface TokenMapper {
    int insert(Token token);
    Token selectByUserId(String userId);
    int updateByPrimaryKey(Token token);
    Token selectByUUID(String UUID);
}
