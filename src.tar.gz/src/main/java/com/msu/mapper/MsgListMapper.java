package com.msu.mapper;

import com.msu.pojo.MsgList;

import java.util.ArrayList;

public interface MsgListMapper {
    int deleteByPrimaryKey(String id);

    int insert(MsgList record);

    int insertSelective(MsgList record);

    MsgList selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(MsgList record);

    int updateByPrimaryKey(MsgList record);

    MsgList selectByMeAndFriend(String myId, String myFriendId);

    ArrayList<MsgList> selectMyLastTenMsg(String id);
}