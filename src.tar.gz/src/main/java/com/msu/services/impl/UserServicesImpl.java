package com.msu.services.impl;

import com.idworker.Sid;
import com.msu.enums.MsgSignFlagEnum;
import com.msu.mapper.*;
import com.msu.netty.ChatMsg;
import com.msu.pojo.*;
import com.msu.services.UserServices;
import org.springframework.stereotype.Service;

import sun.misc.BASE64Decoder;

import java.io.*;
import javax.annotation.Resource;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
public class UserServicesImpl implements UserServices {

    @Resource
    UserMapper userMapper;

    @Resource
    UserHomeMapper userHomeMapper;

    @Resource
    FriendsRequestMapper friendsRequestMapper;

    @Resource
    MyFriendsMapper myFriendsMapper;

    @Resource
    TokenMapper tokenMapper;

    @Resource
    Sid sid;

    @Resource
    ChatMsgMapper chatMsgMapper;

    @Resource
    MsgListMapper msgListMapper;

    @Resource
    GroupOwnerMapper groupOwnerMapper;

    @Resource
    GroupUsersMapper groupUsersMapper;

    @Override
    public User getUserById(String id) {
        User user = userMapper.selectByPrimaryKey(id);
        return user;
    }

    @Override
    public User getUserByUsername(String username) {
        User user = userMapper.selectByUserName(username);
        return user;
    }

    @Override
    public User insertNewUser(User user) {
        user.setId(sid.nextShort());
        userMapper.insert(user);
        return user;
    }

    @Override
    public FriendsRequest insertNewRequest(FriendsRequest friendsRequest) {
        friendsRequest.setId(sid.nextShort());
        friendsRequestMapper.insert(friendsRequest);
        return friendsRequest;
    }

    @Override
    public ArrayList<FriendsRequest> getRequestByAcceptUser(String id) {
        ArrayList<FriendsRequest> friendsRequests = friendsRequestMapper.selectByAcceptUser(id);
        return friendsRequests;
    }

    @Override
    public FriendsRequest getRequestBySendAndAcceptUser(String sendUser, String acceptUser) {
        return friendsRequestMapper.selectBySendAndAcceptUser(sendUser, acceptUser);
    }

    @Override
    public int deleteFriendsRequestById(String id) {
        friendsRequestMapper.deleteByPrimaryKey(id);
        return 0;
    }

    @Override
    public MyFriends insertNewFriend(MyFriends myFriends) {
        myFriends.setId(sid.nextShort());
        myFriendsMapper.insert(myFriends);
        return myFriends;
    }

    @Override
    public ArrayList<MyFriends> getMyFriendsByMyId(String id) {
        ArrayList<MyFriends> myFriends = myFriendsMapper.selectMyFriendsByMyId(id);
        return myFriends;
    }

    @Override
    public MyFriends getMyFriendsByMeAndFriend(String myId, String friendId) {
        return myFriendsMapper.selectByMeAndFriend(myId, friendId);
    }

    @Override
    public int deleteMyFriendsByMeAndFriend(String myId, String friendId) {
        myFriendsMapper.deleteByMeAndFriend(myId, friendId);
        return 0;
    }

    @Override
    public ArrayList<User> selectByLikeUserName(String id) {
        ArrayList<User> users = userMapper.selectByLikeUserName(id);
        return users;
    }

    @Override
    public UserHome getHomeByUserName(String username) {
        return userHomeMapper.selectByUserName(username);
    }

    @Override
    public UserHome insertNewUserHome(UserHome userHome) {
        userHome.setId(sid.nextShort());
        userHomeMapper.insert(userHome);
        return userHome;
    }

    @Override
    public int updateHomeById(UserHome userHome) {
        return userHomeMapper.updateByPrimaryKey(userHome);
    }

    @Override
    public String saveMsg(ChatMsg chatMsg) {
        com.msu.pojo.ChatMsg msgDB = new com.msu.pojo.ChatMsg();
        String msgId = sid.nextShort();
        msgDB.setId(msgId);
        msgDB.setAcceptUserId(chatMsg.getReceiverId());
        msgDB.setSendUserId(chatMsg.getSenderId());
        msgDB.setCreateTime(new Date());
        msgDB.setSignFlag(MsgSignFlagEnum.unsign.type);
        msgDB.setMsg(chatMsg.getMsg());

        chatMsgMapper.insert(msgDB);

        return msgId;
    }

    @Override
    public void updateMsgSigned(List<String> msgIdList) {
        userMapper.batchUpdateMsgSigned(msgIdList);
    }

    @Override
    public void blindUUID(String userId, String UUID) {
        Token token = new Token(userId, UUID);
        Token tokenRes = tokenMapper.selectByUserId(userId);
        if (tokenRes == null) {
            tokenMapper.insert(token);
        } else {
            tokenMapper.updateByPrimaryKey(token);
        }
    }

    @Override
    public String checkUsername(String UUID) {
        Token tokenRes = tokenMapper.selectByUUID(UUID);
        if (tokenRes == null) {
            return "";
        } else {
            User user = userMapper.selectByPrimaryKey(tokenRes.getUserId());
            return user.getUsername();
        }
    }

    @Override
    public boolean checkUUID(String UUID) {
        Token tokenRes = tokenMapper.selectByUUID(UUID);
        if (tokenRes == null) {
            return false;
        } else {
            LocalDateTime tokenDate = LocalDateTime.parse(tokenRes.getLocalDate());
            Duration duration = Duration.between(tokenDate, LocalDateTime.now());
            if (duration.getSeconds() / (60 * 60) > 3) {
                //3小时之内UUID有效
                return false;
            } else {
                return true;
            }
        }
    }

    @Override
    public ArrayList<com.msu.pojo.ChatMsg> getUnreadMsgByUserId(String sendId, String acceptId) {
        ArrayList<com.msu.pojo.ChatMsg> messages = chatMsgMapper.selectUnreadMsgByUserId(sendId, acceptId);
        return messages;
    }

    @Override
    public MsgList getByMeAndFriend(String myId, String myFriendId) {
        return msgListMapper.selectByMeAndFriend(myId, myFriendId);
    }

    @Override
    public ArrayList<MsgList> getMyLastTenMsg(String id) {
        return msgListMapper.selectMyLastTenMsg(id);
    }

    @Override
    public ArrayList<com.msu.pojo.ChatMsg> getMsgByUserId(String sendId, String acceptId) {
        return chatMsgMapper.selectMsgByUserId(sendId,acceptId);
    }

    @Override
    public void updateMsgSignFlag(com.msu.pojo.ChatMsg chatMsg) {
        chatMsgMapper.updateByPrimaryKey(chatMsg);
    }

    @Override
    public String saveImage(String base64Data) {
        String dataPrix = ""; //base64格式前头
        String data = "";//实体部分数据
        if (base64Data == null || "".equals(base64Data)) {
            return null;
        } else {
            String[] d = base64Data.split("base64,");//将字符串分成数组
            if (d != null && d.length == 2) {
                dataPrix = d[0];
                data = d[1];
            } else {
                return null;
            }
        }
        String suffix = "";//图片后缀，用以识别哪种格式数据
        //data:image/jpeg;base64,base64编码的jpeg图片数据
        if ("data:image/jpeg;".equalsIgnoreCase(dataPrix)) {
            suffix = ".jpg";
        } else if ("data:image/x-icon;".equalsIgnoreCase(dataPrix)) {
            //data:image/x-icon;base64,base64编码的icon图片数据
            suffix = ".ico";
        } else if ("data:image/gif;".equalsIgnoreCase(dataPrix)) {
            //data:image/gif;base64,base64编码的gif图片数据
            suffix = ".gif";
        } else if ("data:image/png;".equalsIgnoreCase(dataPrix)) {
            //data:image/png;base64,base64编码的png图片数据
            suffix = ".png";
        } else {
            return null;
        }
        String uuid = UUID.randomUUID().toString();
        String tempFileName = uuid + suffix;
        String imgFilePath = "/home/asterism/Avatar/" + tempFileName;//新生成的图片
        BASE64Decoder decoder = new BASE64Decoder();
        try {
            //Base64解码
            byte[] b = decoder.decodeBuffer(data);
            for (int i = 0; i < b.length; ++i) {
                if (b[i] < 0) {
                    //调整异常数据
                    b[i] += 256;
                }
            }
            OutputStream out = new FileOutputStream(imgFilePath);
            out.write(b);
            out.flush();
            out.close();

            String imgurl = "http://106.53.58.194:8082/" + tempFileName;
            return imgurl;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

    }

    @Override
    public void updateMsgList(MsgList msgList) {
        msgListMapper.updateByPrimaryKey(msgList);
    }

    @Override
    public void insertNewGroupOwner(GroupOwner groupOwner) {
        groupOwner.setId(sid.nextShort());
        groupOwnerMapper.insert(groupOwner);
        return;
    }

    @Override
    public GroupOwner getGroupOwner(String groupName) {
        return groupOwnerMapper.selectByGroupName(groupName);
    }

    @Override
    public void insertNewGroupUser(GroupUsers groupUsers) {
        groupUsers.setId(sid.nextShort());
        groupUsersMapper.insert(groupUsers);
        return;
    }

    @Override
    public ArrayList<GroupUsers> getGroupAllUsers(String groupName) {
        return groupUsersMapper.selectByGroupName(groupName);
    }

    @Override
    public ArrayList<User> getGroupOwnerAndUsers(String groupName) {
        GroupOwner groupOwner = getGroupOwner(groupName);
        User user = new User();
        user = getUserByUsername(groupOwner.getUsername());
        ArrayList<GroupUsers> groupUsers = new ArrayList<>();
        groupUsers = getGroupAllUsers(groupName);
        ArrayList<User> users = new ArrayList<>();
        users.add(user);
        for(int i = 0; i < groupUsers.size(); i++){
            users.add(getUserByUsername(groupUsers.get(i).getUsername()));
        }
        return users;
    }

    @Override
    public GroupUsers getGroupUsers(String groupName, String username) {
        return groupUsersMapper.selectByGroupNameAndUsername(groupName, username);
    }

    @Override
    public ArrayList<GroupOwner> getGroupOwnerByLikeUsername(String groupName) {
        return groupOwnerMapper.selectByLikeGroup(groupName);
    }

    @Override
    public ArrayList<GroupOwner> getGroupOwnerByUsername(String username) {
        return groupOwnerMapper.selectByUsername(username);
    }

    @Override
    public ArrayList<GroupUsers> getGroupUsersByUsername(String username) {
        return groupUsersMapper.selectByUsername(username);
    }
}
