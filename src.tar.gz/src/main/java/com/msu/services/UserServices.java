package com.msu.services;

import com.msu.netty.ChatMsg;
import com.msu.pojo.*;

import java.util.ArrayList;
import java.util.List;

public interface UserServices {
    User getUserById(String id);

    User getUserByUsername(String username);

    ArrayList<User> selectByLikeUserName(String id);

    User insertNewUser(User user);

    FriendsRequest insertNewRequest(FriendsRequest friendsRequest);

    ArrayList<FriendsRequest> getRequestByAcceptUser(String id);

    FriendsRequest getRequestBySendAndAcceptUser(String sendUser,String acceptUser);

    int deleteFriendsRequestById(String id);

    MyFriends insertNewFriend(MyFriends myFriends);

    ArrayList<MyFriends> getMyFriendsByMyId(String id);

    MyFriends getMyFriendsByMeAndFriend(String myId, String friendId);

    int deleteMyFriendsByMeAndFriend(String myId, String friendId);

    UserHome getHomeByUserName(String username);

    UserHome insertNewUserHome(UserHome userHome);

    int updateHomeById(UserHome userHome);

    String saveMsg(ChatMsg chatMsg);

    void updateMsgSigned(List<String> msgIdList);

    void blindUUID(String userId, String UUID) ;

    String checkUsername(String UUID);

    boolean checkUUID(String UUID);

    ArrayList<com.msu.pojo.ChatMsg> getUnreadMsgByUserId(String id);

    MsgList getByMeAndFriend(String myId, String myFriendId);

    ArrayList<MsgList> getMyLastTenMsg(String id);
}
