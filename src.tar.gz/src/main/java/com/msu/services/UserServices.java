package com.msu.services;

import com.msu.netty.ChatMsg;
import com.msu.pojo.*;

import java.util.ArrayList;
import java.util.List;

public interface UserServices {
    User getUserById(String id);

    User getUserByUsername(String username);

    ArrayList<User> selectByLikeUserName(String id);

    User insertNewUser(User user);

    FriendsRequest insertNewRequest(FriendsRequest friendsRequest);

    ArrayList<FriendsRequest> getRequestByAcceptUser(String id);

    FriendsRequest getRequestBySendAndAcceptUser(String sendUser,String acceptUser);

    int deleteFriendsRequestById(String id);

    MyFriends insertNewFriend(MyFriends myFriends);

    ArrayList<MyFriends> getMyFriendsByMyId(String id);

    MyFriends getMyFriendsByMeAndFriend(String myId, String friendId);

    int deleteMyFriendsByMeAndFriend(String myId, String friendId);

    UserHome getHomeByUserName(String username);

    UserHome insertNewUserHome(UserHome userHome);

    int updateHomeById(UserHome userHome);

    String saveMsg(ChatMsg chatMsg);

    void updateMsgSigned(List<String> msgIdList);

    void blindUUID(String userId, String UUID) ;

    String checkUsername(String UUID);

    boolean checkUUID(String UUID);

    ArrayList<com.msu.pojo.ChatMsg> getUnreadMsgByUserId(String sendId, String acceptId);

    MsgList getByMeAndFriend(String myId, String myFriendId);

    ArrayList<MsgList> getMyLastTenMsg(String id);

    ArrayList<com.msu.pojo.ChatMsg> getMsgByUserId(String sendId, String acceptId);

    void updateMsgSignFlag(com.msu.pojo.ChatMsg chatMsg);

    String saveImage(String base64Data);

    void updateMsgList(MsgList msgList);

    void insertNewGroupOwner(GroupOwner groupOwner);

    GroupOwner getGroupOwner(String groupName);

    void insertNewGroupUser(GroupUsers groupUsers);

    ArrayList<GroupUsers> getGroupAllUsers(String groupName);

    ArrayList<User> getGroupOwnerAndUsers(String groupName);

    GroupUsers getGroupUsers(String groupName, String username);

    ArrayList<GroupOwner> getGroupOwnerByLikeUsername(String groupName);

    ArrayList<GroupOwner> getGroupOwnerByUsername(String username);

    ArrayList<GroupUsers> getGroupUsersByUsername(String username);
}
