package com.msu.controller;

import com.msu.pojo.ChatMsg;
import com.msu.pojo.MsgList;
import com.msu.pojo.UserHome;
import com.msu.response.*;
import com.msu.rjson.*;
import com.msu.pojo.User;
import com.msu.services.UserServices;
import com.msu.utils.SHA256Util;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.Collections;
import java.util.UUID;

@CrossOrigin(origins = "*", maxAge = 3600)
@Service
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserServices userServices;

    @ResponseBody
    @RequestMapping("/getUser")
    public RespEntity getUserById() {

        ArrayList<User> users = userServices.selectByLikeUserName("");
        return new RespEntity(RespCode.SUCCESS, users);

    }


    @ResponseBody
    @RequestMapping(value = "/login")
    public RespEntity login(@RequestBody ReqUser reqUser) {
        String password = SHA256Util.getSHA256StrJava(reqUser.getPassword());
        User user;
        user = userServices.getUserByUsername(reqUser.getUsername());
        if (user == null) {
            return new RespEntity(RespCode.WARN, null);
        } else if (!user.getPassword().equals(password)) {
            return new RespEntity(RespCode.WARN, null);
        } else {
            LoginRes loginRes = new LoginRes();
            UserInfo userInfo = new UserInfo();
            String uuid = UUID.randomUUID().toString();

            BeanUtils.copyProperties(user, userInfo);
            loginRes.setUserInfo(userInfo);
            loginRes.setToken(uuid);
            userServices.blindUUID(user.getId(), uuid);

            return new RespEntity(RespCode.SUCCESS, loginRes);
        }
    }

    @ResponseBody
    @RequestMapping(value = "/register")
    //{username ; password}are required
    public RespEntity register(@RequestBody ReqUser request) {
        String password = SHA256Util.getSHA256StrJava(request.getPassword());
        User user = new User();

        User tuser = userServices.getUserByUsername(request.getUsername());
        if (tuser != null)
            // if the username is already occupied, return fail
            return new RespEntity(RespCode.WARN, null);

        user.setUsername(request.getUsername());
        user.setPassword(password);
        user.setCid("");
        user.setFaceImage("");
        user.setNickname("fker");
        user.setFaceImageBig("faker");
        user.setQrcode("nothing");

        User userResult = userServices.insertNewUser(user);
        UserHome userHome = new UserHome();
        userHome.setUserId(user.getId());
        userHome.setUsername(user.getUsername());
        userHome.setFaceImage(user.getFaceImage());
        userHome.setFaceImageBig(user.getFaceImageBig());
        userHome.setNickname(user.getNickname());
        userHome.setUserSignature("");
        userHome.setGender(-1);
        UserHome result = userServices.insertNewUserHome(userHome);
        return new RespEntity(RespCode.SUCCESS, userResult.getUsername());
    }

    @ResponseBody
    @RequestMapping("/home")
    public RespEntity home(@RequestBody ReqUser reqUser) {
        if (!userServices.checkUUID(reqUser.getUUID())) {
            return new RespEntity(RespCode.WARN, null);
        }
        if (!userServices.checkUsername(reqUser.getUUID()).equals(reqUser.getUsername())) {
            String st = userServices.checkUsername(reqUser.getUUID());
            return new RespEntity(RespCode.WARN, null);
        }

        User user;
        user = userServices.getUserByUsername(reqUser.getUsername());
        UserHome userHome = new UserHome();
        if (userServices.getHomeByUserName(reqUser.getUsername()) == null) {
            userHome.setUserId(user.getId());
            userHome.setUsername(user.getUsername());
            userHome.setFaceImage(user.getFaceImage());
            userHome.setFaceImageBig(user.getFaceImageBig());
            userHome.setNickname(user.getNickname());
            userHome.setUserSignature("");
            userHome.setGender(-1);
            UserHome result = userServices.insertNewUserHome(userHome);
        } else {
            userHome = userServices.getHomeByUserName(reqUser.getUsername());
        }
        return new RespEntity(RespCode.SUCCESS, userHome);
    }

    @ResponseBody
    @RequestMapping("/home/setNickname")
    public RespEntity setNickname(@RequestBody ReqNickname reqNickname) {
        if (!userServices.checkUUID(reqNickname.getUUID())) {
            return new RespEntity(RespCode.WARN, null);
        }
        if (!userServices.checkUsername(reqNickname.getUUID()).equals(reqNickname.getUsername())) {
            String st = userServices.checkUsername(reqNickname.getUUID());
            return new RespEntity(RespCode.WARN, null);
        }

        UserHome userHome = new UserHome();
        userHome = userServices.getHomeByUserName(reqNickname.getUsername());
        userHome.setNickname(reqNickname.getNickname());
        int result = userServices.updateHomeById(userHome);
        return new RespEntity(RespCode.SUCCESS, reqNickname);
    }

    @ResponseBody
    @RequestMapping("/home/setGender")
    public RespEntity setGender(@RequestBody ReqGender reqGender) {
        if (!userServices.checkUUID(reqGender.getUUID())) {
            return new RespEntity(RespCode.WARN, null);
        }
        if (!userServices.checkUsername(reqGender.getUUID()).equals(reqGender.getUsername())) {
            String st = userServices.checkUsername(reqGender.getUUID());
            return new RespEntity(RespCode.WARN, null);
        }

        UserHome userHome = new UserHome();
        userHome = userServices.getHomeByUserName(reqGender.getUsername());
        if (reqGender.getGender() != 0 && reqGender.getGender() != 1) {
            return new RespEntity(RespCode.WARN);
        }
        userHome.setGender(reqGender.getGender());
        int result = userServices.updateHomeById(userHome);
        return new RespEntity(RespCode.SUCCESS, result);
    }

    @ResponseBody
    @RequestMapping("/home/setSignature")
    public RespEntity setSignature(@RequestBody ReqUserSignature reqUserSignature) {
        if (!userServices.checkUUID(reqUserSignature.getUUID())) {
            return new RespEntity(RespCode.WARN, null);
        }
        if (!userServices.checkUsername(reqUserSignature.getUUID()).equals(reqUserSignature.getUsername())) {
            String st = userServices.checkUsername(reqUserSignature.getUUID());
            return new RespEntity(RespCode.WARN, null);
        }

        UserHome userHome = new UserHome();
        userHome = userServices.getHomeByUserName(reqUserSignature.getUsername());
        userHome.setUserSignature(reqUserSignature.getUserSignature());
        int result = userServices.updateHomeById(userHome);
        return new RespEntity(RespCode.SUCCESS, userHome);
    }

    @ResponseBody
    @RequestMapping("/getUnreadMsgList")
    public RespEntity getUnreadMsgList(@RequestBody ReqUser reqUser) {
        if (!userServices.checkUUID(reqUser.getUUID())) {
            return new RespEntity(RespCode.WARN, null);
        }
        if (!userServices.checkUsername(reqUser.getUUID()).equals(reqUser.getUsername())) {
            String st = userServices.checkUsername(reqUser.getUUID());
            return new RespEntity(RespCode.WARN, null);
        }
        User user = userServices.getUserByUsername(reqUser.getUsername());
        ArrayList<ChatMsg> messages = new ArrayList<>();
        messages = userServices.getUnreadMsgByUserId(user.getId());
        return new RespEntity(RespCode.SUCCESS, messages);
    }

    @ResponseBody
    @RequestMapping("/getLastTenMsg")
    public RespEntity getLastTenMsg(@RequestBody ReqUser reqUser) {
        if (!userServices.checkUUID(reqUser.getUUID())) {
            return new RespEntity(RespCode.WARN, null);
        }
        if (!userServices.checkUsername(reqUser.getUUID()).equals(reqUser.getUsername())) {
            String st = userServices.checkUsername(reqUser.getUUID());
            return new RespEntity(RespCode.WARN, null);
        }
        User user = userServices.getUserByUsername(reqUser.getUsername());
        ArrayList<MsgList> msgLists = new ArrayList<>();
        msgLists = userServices.getMyLastTenMsg(user.getId());
        Collections.sort(msgLists);
        ArrayList<MsgList> msgLists1 = new ArrayList<>();
        for(int i = 0;i < 10 && i < msgLists.size(); i++){
            msgLists1.add(msgLists.get(i));
        }
        return new RespEntity(RespCode.SUCCESS, msgLists);
    }
}
