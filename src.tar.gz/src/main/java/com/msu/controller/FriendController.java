package com.msu.controller;


import com.msu.pojo.FriendsRequest;
import com.msu.pojo.MyFriends;
import com.msu.pojo.User;
import com.msu.rjson.ReqFriend;
import com.msu.rjson.ReqUser;
import com.msu.rjson.RespCode;
import com.msu.rjson.RespEntity;
import com.msu.services.UserServices;
import com.msu.vo.UserVo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@Service
@RequestMapping("/friend")
public class FriendController {
    @Autowired
    UserServices userServices;

    @ResponseBody
    @RequestMapping(value = "/find")
    public RespEntity find(@RequestBody ReqUser reqUser){
        if(!userServices.checkUUID(reqUser.getUUID())){
            return new RespEntity(RespCode.WARN, null);
        }
        User user = new User();
        ArrayList<User> users = userServices.selectByLikeUserName(reqUser.getUsername());
        Collections.sort(users);
        ArrayList<UserVo> userVos = new ArrayList<>();
        for(int i = 0; i < users.size(); i++){
            UserVo userVo = new UserVo();
            BeanUtils.copyProperties(users.get(i),userVo);
            userVos.add(userVo);
        }
        return new RespEntity(RespCode.SUCCESS, userVos);
    }

    @ResponseBody
    @RequestMapping(value = "/sendRequest")
    public RespEntity sendRequest(@RequestBody ReqFriend reqFriend){
        if(!userServices.checkUUID(reqFriend.getUUID())){
            return new RespEntity(RespCode.WARN, null);
        }
        if(!userServices.checkUsername(reqFriend.getUUID()).equals(reqFriend.getSendName())){
            String st=userServices.checkUsername(reqFriend.getUUID());
            return new RespEntity(RespCode.WARN, null);
        }

        String sendUserId = userServices.getUserByUsername(reqFriend.getSendName()).getId();
        String acceptUserId = userServices.getUserByUsername(reqFriend.getAcceptName()).getId();
        FriendsRequest friendsRequest = userServices.getRequestBySendAndAcceptUser(acceptUserId,sendUserId);
        //首先判断是否已经是好友
        if(userServices.getMyFriendsByMeAndFriend(sendUserId,acceptUserId) != null){
            return new RespEntity(RespCode.WARN, "已经是好友");
        }
        //判断是否重复发送好友请求
        if(userServices.getRequestBySendAndAcceptUser(sendUserId,acceptUserId) != null){
            return new RespEntity(RespCode.WARN, "请勿重复发送请求");
        }
        //判断对方是否向自己发送好友请求，若是，则直接成为好友
        if(friendsRequest != null){
            MyFriends myFriends1 = new MyFriends();
            MyFriends myFriends2 = new MyFriends();
            myFriends1.setMyUserId(sendUserId);
            myFriends1.setMyFriendUserId(acceptUserId);
            myFriends2.setMyUserId(acceptUserId);
            myFriends2.setMyFriendUserId(sendUserId);
            userServices.insertNewFriend(myFriends1);
            userServices.insertNewFriend(myFriends2);
            userServices.deleteFriendsRequestById(friendsRequest.getId());
            return new RespEntity(RespCode.SUCCESS, "成为好友");
        }
        Date d=new Date();
        FriendsRequest friendsRequest1 = new FriendsRequest();
        friendsRequest1.setSendUserId(sendUserId);
        friendsRequest1.setAcceptUserId(acceptUserId);
        friendsRequest1.setSendUserName(userServices.getUserById(sendUserId).getUsername());
        friendsRequest1.setAcceptUserName(userServices.getUserById(acceptUserId).getUsername());
        friendsRequest1.setRequestDateTime(d);
        FriendsRequest result = userServices.insertNewRequest(friendsRequest1);
        return new RespEntity(RespCode.SUCCESS, result);
    }

    @ResponseBody
    @RequestMapping(value = "/viewRequest")
    public RespEntity viewRequest(@RequestBody ReqUser reqUser){
        if(!userServices.checkUUID(reqUser.getUUID())){
            return new RespEntity(RespCode.WARN, null);
        }
        if(!userServices.checkUsername(reqUser.getUUID()).equals(reqUser.getUsername())){
            String st=userServices.checkUsername(reqUser.getUUID());
            return new RespEntity(RespCode.WARN, null);
        }

        User user = userServices.getUserByUsername(reqUser.getUsername());
        ArrayList<FriendsRequest> friendsRequests = userServices.getRequestByAcceptUser(user.getId());
        if(friendsRequests.size() == 0)
            return new RespEntity(RespCode.NOREQUEST);
        return new RespEntity(RespCode.SUCCESS, friendsRequests);
    }

    @ResponseBody
    @RequestMapping(value = "/acceptRequest")
    public RespEntity acceptRequest(@RequestBody ReqFriend reqFriend){
        if(!userServices.checkUUID(reqFriend.getUUID())){
            return new RespEntity(RespCode.WARN, null);
        }
        if(!userServices.checkUsername(reqFriend.getUUID()).equals(reqFriend.getAcceptName())){
            String st=userServices.checkUsername(reqFriend.getUUID());
            return new RespEntity(RespCode.WARN, null);
        }

        String sendUserId = userServices.getUserByUsername(reqFriend.getSendName()).getId();
        String acceptUserId = userServices.getUserByUsername(reqFriend.getAcceptName()).getId();
        FriendsRequest friendsRequest = userServices.getRequestBySendAndAcceptUser(sendUserId,acceptUserId);
        if(friendsRequest == null){
            return new RespEntity(RespCode.WARN);
        }
        MyFriends myFriends1 = new MyFriends();
        MyFriends myFriends2 = new MyFriends();
        myFriends1.setMyUserId(sendUserId);
        myFriends1.setMyFriendUserId(acceptUserId);
        myFriends2.setMyUserId(acceptUserId);
        myFriends2.setMyFriendUserId(sendUserId);
        userServices.insertNewFriend(myFriends1);
        userServices.insertNewFriend(myFriends2);
        userServices.deleteFriendsRequestById(friendsRequest.getId());
        return new RespEntity(RespCode.SUCCESS, "添加成功");
    }

    @ResponseBody
    @RequestMapping(value = "/refuseRequest")
    public RespEntity refuseRequest(@RequestBody ReqFriend reqFriend){
        if(!userServices.checkUUID(reqFriend.getUUID())){
            return new RespEntity(RespCode.WARN, null);
        }
        if(!userServices.checkUsername(reqFriend.getUUID()).equals(reqFriend.getAcceptName())){
            String st=userServices.checkUsername(reqFriend.getUUID());
            return new RespEntity(RespCode.WARN, null);
        }

        String sendUserId = userServices.getUserByUsername(reqFriend.getSendName()).getId();
        String acceptUserId = userServices.getUserByUsername(reqFriend.getAcceptName()).getId();
        FriendsRequest friendsRequest = userServices.getRequestBySendAndAcceptUser(sendUserId,acceptUserId);
        if(friendsRequest == null){
            return new RespEntity(RespCode.WARN);
        }
        userServices.deleteFriendsRequestById(friendsRequest.getId());
        return new RespEntity(RespCode.SUCCESS, "已拒绝");
    }

    @ResponseBody
    @RequestMapping(value = "/viewMyFriends")
    public RespEntity viewMyFriends(@RequestBody ReqUser reqUser){
        if(!userServices.checkUUID(reqUser.getUUID())){
            return new RespEntity(RespCode.WARN, null);
        }
        if(!userServices.checkUsername(reqUser.getUUID()).equals(reqUser.getUsername())){
            String st=userServices.checkUsername(reqUser.getUUID());
            return new RespEntity(RespCode.WARN, null);
        }

        User user = userServices.getUserByUsername(reqUser.getUsername());
        ArrayList<MyFriends> myFriends= userServices.getMyFriendsByMyId(user.getId());
        ArrayList<User> users = new ArrayList<>();
        for(int i = 0; i < myFriends.size(); i++){
            users.add(userServices.getUserById(myFriends.get(i).getMyFriendUserId()));
        }
        Collections.sort(users);
        Map<Character,ArrayList<User>> map = sort(users);
        return new RespEntity(RespCode.SUCCESS, map);
    }

    @ResponseBody
    @RequestMapping(value = "/deleteMyFriends")
    public  RespEntity deleteMyFriends(@RequestBody ReqFriend reqFriend){
        if(!userServices.checkUUID(reqFriend.getUUID())){
            return new RespEntity(RespCode.WARN, null);
        }
        if(!userServices.checkUsername(reqFriend.getUUID()).equals(reqFriend.getSendName())){
            String st=userServices.checkUsername(reqFriend.getUUID());
            return new RespEntity(RespCode.WARN, null);
        }

        String myId = userServices.getUserByUsername(reqFriend.getSendName()).getId();
        String friendId = userServices.getUserByUsername(reqFriend.getAcceptName()).getId();
        userServices.deleteMyFriendsByMeAndFriend(myId,friendId);
        userServices.deleteMyFriendsByMeAndFriend(friendId,myId);
        return new RespEntity(RespCode.SUCCESS, "删除完毕");
    }

    //并返回键值对，按首字母排序
    public Map sort(ArrayList<User> users){
        Map<Character,ArrayList<User>> map = new TreeMap<Character,ArrayList<User>>();
        ArrayList<User> users1 = new ArrayList<>();
        for (int i = 0; i < users.size(); i++){
            if(map.containsKey(users.get(i).getFirstLetter()) == true){
                users1 = map.get(users.get(i).getFirstLetter());
            }
            else{
                users1 = new ArrayList<>();
            }
            users1.add(users.get(i));
            map.put(users.get(i).getFirstLetter(),users1);
        }
        return map;
    }
}
