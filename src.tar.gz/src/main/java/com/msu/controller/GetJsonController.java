package com.msu.controller;

import com.msu.rjson.ReqUser;
import com.msu.rjson.RespCode;
import com.msu.rjson.RespEntity;
import com.msu.pojo.User;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/t_user")
public class GetJsonController {

    @RequestMapping("/register")
    public RespEntity register(@RequestBody ReqUser reqUser){
        User user = new User();
        if(reqUser != null){
            user.setUsername(reqUser.getUsername());
            user.setPassword(reqUser.getPassword());
        }
        return new RespEntity(RespCode.SUCCESS, user);

    }
}
