package com.msu.controller;

import com.msu.pojo.GroupOwner;
import com.msu.pojo.GroupUsers;
import com.msu.pojo.User;
import com.msu.rjson.*;
import com.msu.services.UserServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

@CrossOrigin(origins = "*", maxAge = 3600)
@Service
@RequestMapping("/group")
public class GroupController {
    @Autowired
    UserServices userServices;

    @ResponseBody
    @RequestMapping("/createGroup")
    public RespEntity createGroup(@RequestBody ReqGroupUser reqGroupUser) {
        if(!userServices.checkUUID(reqGroupUser.getUUID())){
            return new RespEntity(RespCode.WARN, null);
        }
        if(!userServices.checkUsername(reqGroupUser.getUUID()).equals(reqGroupUser.getUsername())){
            String st=userServices.checkUsername(reqGroupUser.getUUID());
            return new RespEntity(RespCode.WARN, null);
        }
        String groupName = reqGroupUser.getGroupName();
        String ownerName = reqGroupUser.getUsername();
        GroupOwner groupOwner = new GroupOwner();
        if(userServices.getGroupOwner(groupName) != null){
            return new RespEntity(RespCode.WARN, "群聊名重复");
        }
        groupOwner.setGroupName(groupName);
        groupOwner.setUsername(ownerName);
        userServices.insertNewGroupOwner(groupOwner);
        return new RespEntity(RespCode.SUCCESS);
    }

    @ResponseBody
    @RequestMapping("/joinGroup")
    public RespEntity joinGroup(@RequestBody ReqGroupUser reqGroupUser) {
        if(!userServices.checkUUID(reqGroupUser.getUUID())){
            return new RespEntity(RespCode.WARN, null);
        }
        if(!userServices.checkUsername(reqGroupUser.getUUID()).equals(reqGroupUser.getUsername())){
            String st=userServices.checkUsername(reqGroupUser.getUUID());
            return new RespEntity(RespCode.WARN, null);
        }
        String groupName = reqGroupUser.getGroupName();
        String username = reqGroupUser.getUsername();
        if(userServices.getGroupUsers(groupName, username) != null){
            return new RespEntity(RespCode.WARN, "已加入该群聊");
        }
        GroupUsers groupUsers = new GroupUsers();
        groupUsers.setGroupName(groupName);
        groupUsers.setUsername(username);
        userServices.insertNewGroupUser(groupUsers);
        return new RespEntity(RespCode.SUCCESS);
    }

    @ResponseBody
    @RequestMapping("/returnGroupMembers")
    public RespEntity returnGroupMembers(@RequestBody ReqGroupUser reqGroupUser) {
        if(!userServices.checkUUID(reqGroupUser.getUUID())){
            return new RespEntity(RespCode.WARN, null);
        }
        String groupName = reqGroupUser.getGroupName();
        ArrayList<User> users = new ArrayList<>();
        users = userServices.getGroupOwnerAndUsers(groupName);
        return new RespEntity(RespCode.SUCCESS, users);
    }

    @ResponseBody
    @RequestMapping("/searchGroup")
    public RespEntity searchGroup(@RequestBody ReqGroupUser reqGroupUser) {
        if(!userServices.checkUUID(reqGroupUser.getUUID())){
            return new RespEntity(RespCode.WARN, null);
        }
        String groupName = reqGroupUser.getGroupName();
        ArrayList<GroupOwner> groupOwners = userServices.getGroupOwnerByLikeUsername(groupName);
        return new RespEntity(RespCode.SUCCESS, groupOwners);
    }

    @ResponseBody
    @RequestMapping("/returnGroupList")
    public RespEntity returnGroupList(@RequestBody ReqUser reqUser) {
        if(!userServices.checkUUID(reqUser.getUUID())){
            return new RespEntity(RespCode.WARN, null);
        }
        if(!userServices.checkUsername(reqUser.getUUID()).equals(reqUser.getUsername())){
            String st=userServices.checkUsername(reqUser.getUUID());
            return new RespEntity(RespCode.WARN, null);
        }
        String username = reqUser.getUsername();
        ArrayList<GroupOwner> groupOwners = userServices.getGroupOwnerByUsername(username);
        ArrayList<GroupUsers> groupOwners1 = userServices.getGroupUsersByUsername(username);
        for(int i = 0; i < groupOwners1.size(); i++){
            groupOwners.add(userServices.getGroupOwner(groupOwners1.get(i).getGroupName()));
        }
        return new RespEntity(RespCode.SUCCESS, groupOwners);
    }
}
