package com.msu.rjson;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ReqFriend {
    @JsonProperty(value = "Token")
    private String UUID;

    @JsonProperty(value = "sendName")
    String sendName;

    @JsonProperty(value = "acceptName")
    String acceptName;

    public String getUUID() {
        return UUID;
    }

    public void setUUID(String UUID) {
        this.UUID = UUID;
    }

    public String getSendName() {
        return sendName;
    }

    public void setSendName(String sendName) {
        this.sendName = sendName;
    }

    public String getAcceptName() {
        return acceptName;
    }

    public void setAcceptName(String acceptName) {
        this.acceptName = acceptName;
    }
}
