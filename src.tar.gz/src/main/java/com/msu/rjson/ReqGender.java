package com.msu.rjson;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ReqGender {
    @JsonProperty(value = "Token")
    private String UUID;

    @JsonProperty(value = "username")
    String username;

    @JsonProperty(value = "gender")
    int gender;

    public String getUUID() {
        return UUID;
    }

    public void setUUID(String UUID) {
        this.UUID = UUID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }
}
