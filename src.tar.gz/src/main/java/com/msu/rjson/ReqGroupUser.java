package com.msu.rjson;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ReqGroupUser {
    @JsonProperty(value = "Token")
    private String UUID;

    @JsonProperty(value = "groupName")
    String groupName;

    @JsonProperty(value = "username")
    String username;

    public String getUUID() {
        return UUID;
    }

    public void setUUID(String UUID) {
        this.UUID = UUID;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
