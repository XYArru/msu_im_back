package com.msu.rjson;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ReqImage {
    @JsonProperty(value = "Token")
    private String UUID;

    @JsonProperty(value = "username")
    String username;

    @JsonProperty(value = "image")
    String image;

    public String getUUID() {
        return UUID;
    }

    public void setUUID(String UUID) {
        this.UUID = UUID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}

