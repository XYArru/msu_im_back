package com.msu.pojo;

import java.util.Date;

public class MsgList implements Comparable<MsgList>{
    private String id;

    private String myId;

    private String myFriendId;

    private Date time;

    private String lastMsg;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMyId() {
        return myId;
    }

    public void setMyId(String myId) {
        this.myId = myId;
    }

    public String getMyFriendId() {
        return myFriendId;
    }

    public void setMyFriendId(String myFriendId) {
        this.myFriendId = myFriendId;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getLastMsg() {
        return lastMsg;
    }

    public void setLastMsg(String lastMsg) {
        this.lastMsg = lastMsg;
    }

    @Override
    public int compareTo(MsgList msgList){
        int i = this.time.compareTo(msgList.getTime());
        return -i;
    }
}