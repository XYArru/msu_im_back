package com.msu.pojo;

import java.time.LocalDateTime;

public class Token {
    private String userId;
    private String UUID;
    private String localDate;

    public Token(String userId, String UUID) {
        this.userId = userId;
        this.UUID = UUID;
        localDate= LocalDateTime.now().toString();
    }

    public Token(String userId, String UUID, String localDate) {
        this.userId = userId;
        this.UUID = UUID;
        this.localDate = localDate;
    }

    public String getLocalDate() {
        return localDate;
    }

    public void setLocalDate(String localDate) {
        this.localDate = localDate;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUUID() {
        return UUID;
    }

    public void setUUID(String UUID) {
        this.UUID = UUID;
    }
}
