package com.msu.token;

import java.util.UUID;

public class Token {
    public static String getUUID(){
        UUID uuid=UUID.randomUUID();
        String str = uuid.toString();
        String uuidStr=str.replace("-", "");
        return uuidStr;
    }

    public static boolean blindUUID(String username,String UUID){
        return true;
    }

    public static String checkUUID(String UUID){
        return "";
    }
}
