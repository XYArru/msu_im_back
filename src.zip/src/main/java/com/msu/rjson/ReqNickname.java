package com.msu.rjson;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ReqNickname {
    @JsonProperty(value = "username")
    String username;

    @JsonProperty(value = "nickname")
    String nickname;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }
}

