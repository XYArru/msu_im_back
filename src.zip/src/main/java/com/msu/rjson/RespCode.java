package com.msu.rjson;

import org.omg.PortableInterceptor.SUCCESSFUL;

public enum  RespCode {
    SUCCESS(200, "请求成功"),
    WARN(500, "网络异常，请稍后重试"),
    NOREQUEST( 501, "无好友请求");

    private int code;
    private String msg;

    RespCode(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }
    public String getMsg() {
        return msg;
    }
}
