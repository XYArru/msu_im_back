package com.msu.rjson;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ReqUserSignature {
    @JsonProperty(value = "username")
    String username;

    @JsonProperty(value = "userSignature")
    String userSignature;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserSignature() {
        return userSignature;
    }

    public void setUserSignature(String userSignature) {
        this.userSignature = userSignature;
    }
}
