package com.msu.mapper;

import com.msu.pojo.UserHome;

public interface UserHomeMapper {
    int deleteByPrimaryKey(String id);

    int insert(UserHome record);

    int insertSelective(UserHome record);

    UserHome selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(UserHome record);

    int updateByPrimaryKey(UserHome record);

    UserHome selectByUserName(String username);
}