package com.msu.mapper;

import com.msu.pojo.User;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

public interface UserMapper {
    int deleteByPrimaryKey(String id);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(String id);

    User selectByUserName(String username);

    ArrayList<User> selectByLikeUserName(String id);


    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);

    void batchUpdateMsgSigned(List<String> msgIdList);
}