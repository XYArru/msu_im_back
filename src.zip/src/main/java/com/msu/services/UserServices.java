package com.msu.services;

import com.msu.netty.ChatMsg;
import com.msu.pojo.FriendsRequest;
import com.msu.pojo.MyFriends;
import com.msu.pojo.User;
import com.msu.pojo.UserHome;

import java.util.ArrayList;
import java.util.List;

public interface UserServices {
    User getUserById(String id);

    User getUserByUsername(String username);

    ArrayList<User> selectByLikeUserName(String id);

    User insertNewUser(User user);

    FriendsRequest insertNewRequest(FriendsRequest friendsRequest);

    ArrayList<FriendsRequest> getRequestByAcceptUser(String id);

    FriendsRequest getRequestBySendAndAcceptUser(String sendUser,String acceptUser);

    int deleteFriendsRequestById(String id);

    MyFriends insertNewFriend(MyFriends myFriends);

    ArrayList<MyFriends> getMyFriendsByMyId(String id);

    MyFriends getMyFriendsByMeAndFriend(String myId, String friendId);

    int deleteMyFriendsByMeAndFriend(String myId, String friendId);

    UserHome getHomeByUserName(String username);

    UserHome insertNewUserHome(UserHome userHome);

    int updateHomeById(UserHome userHome);

    String saveMsg(ChatMsg chatMsg);

    void updateMsgSigned(List<String> msgIdList);
}
