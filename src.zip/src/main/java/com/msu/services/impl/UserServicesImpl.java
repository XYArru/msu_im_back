package com.msu.services.impl;

import com.idworker.Sid;
import com.msu.enums.MsgSignFlagEnum;
import com.msu.mapper.*;
import com.msu.netty.ChatMsg;
import com.msu.pojo.FriendsRequest;
import com.msu.pojo.MyFriends;
import com.msu.pojo.User;
import com.msu.pojo.UserHome;
import com.msu.services.UserServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class UserServicesImpl implements UserServices {

    @Resource
    UserMapper userMapper;

    @Resource
    UserHomeMapper userHomeMapper;

    @Resource
    FriendsRequestMapper friendsRequestMapper;

    @Resource
    MyFriendsMapper myFriendsMapper;

    @Resource
    Sid sid;

    @Resource
    ChatMsgMapper chatMsgMapper;

    @Override
    public User getUserById(String id) {

        User user = userMapper.selectByPrimaryKey(id);
        return user;
    }

    @Override
    public User getUserByUsername(String username) {
        User user = userMapper.selectByUserName(username);
        return user;
    }

    @Override
    public User insertNewUser(User user) {
        user.setId(sid.nextShort());
        userMapper.insert(user);
        return user;
    }

    @Override
    public FriendsRequest insertNewRequest(FriendsRequest friendsRequest) {
        friendsRequest.setId(sid.nextShort());
        friendsRequestMapper.insert(friendsRequest);
        return friendsRequest;
    }

    @Override
    public ArrayList<FriendsRequest> getRequestByAcceptUser(String id) {
        ArrayList<FriendsRequest> friendsRequests= friendsRequestMapper.selectByAcceptUser(id);
        return friendsRequests;
    }

    @Override
    public FriendsRequest getRequestBySendAndAcceptUser(String sendUser, String acceptUser) {
        return friendsRequestMapper.selectBySendAndAcceptUser(sendUser,acceptUser);
    }

    @Override
    public int deleteFriendsRequestById(String id) {
        friendsRequestMapper.deleteByPrimaryKey(id);
        return 0;
    }

    @Override
    public MyFriends insertNewFriend(MyFriends myFriends) {
        myFriends.setId(sid.nextShort());
        myFriendsMapper.insert(myFriends);
        return myFriends;
    }

    @Override
    public ArrayList<MyFriends> getMyFriendsByMyId(String id) {
        ArrayList<MyFriends> myFriends = myFriendsMapper.selectMyFriendsByMyId(id);
        return myFriends;
    }

    @Override
    public MyFriends getMyFriendsByMeAndFriend(String myId, String friendId) {
        return myFriendsMapper.selectByMeAndFriend(myId,friendId);
    }

    @Override
    public int deleteMyFriendsByMeAndFriend(String myId, String friendId) {
        myFriendsMapper.deleteByMeAndFriend(myId,friendId);
        return 0;
    }

    @Override
    public ArrayList<User> selectByLikeUserName(String id){
        ArrayList<User> users = userMapper.selectByLikeUserName(id);
        return users;
    }

    @Override
    public UserHome getHomeByUserName(String username) {
        return userHomeMapper.selectByUserName(username);
    }

    @Override
    public UserHome insertNewUserHome(UserHome userHome) {
        userHome.setId(sid.nextShort());
        userHomeMapper.insert(userHome);
        return userHome;
    }

    @Override
    public int updateHomeById(UserHome userHome) {
        return userHomeMapper.updateByPrimaryKey(userHome);
    }

    @Override
    public String saveMsg(ChatMsg chatMsg) {
        com.msu.pojo.ChatMsg msgDB = new com.msu.pojo.ChatMsg();
        String msgId = sid.nextShort();
        msgDB.setId(msgId);
        msgDB.setAcceptUserId(chatMsg.getReceiverId());
        msgDB.setSendUserId(chatMsg.getSenderId());
        msgDB.setCreateTime(new Date());
        msgDB.setSignFlag(MsgSignFlagEnum.unsign.type);
        msgDB.setMsg(chatMsg.getMsg());

        chatMsgMapper.insert(msgDB);

        return msgId;
    }

    @Override
    public void updateMsgSigned(List<String> msgIdList) {
        userMapper.batchUpdateMsgSigned(msgIdList);
    }

}
