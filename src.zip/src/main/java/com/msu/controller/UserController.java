package com.msu.controller;

import com.msu.token.Token;
import com.msu.pojo.UserHome;
import com.msu.response.*;
import com.msu.rjson.*;
import com.msu.pojo.User;
import com.msu.services.UserServices;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import sun.rmi.runtime.Log;

import java.util.ArrayList;

@CrossOrigin(origins = "*", maxAge = 3600)
@Service
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserServices userServices;

    @ResponseBody
    @RequestMapping("/getUser")
    public RespEntity getUserById() {

        ArrayList<User> users = userServices.selectByLikeUserName("");
        return new RespEntity(RespCode.SUCCESS, users);

    }


    @ResponseBody
    @RequestMapping(value = "/login")
    public RespEntity login(@RequestBody ReqUser reqUser) {
        User user ;
        user = userServices.getUserByUsername(reqUser.getUsername());
        if (user == null) {
            return new RespEntity(RespCode.WARN, null);
        }

        LoginRes loginRes = new LoginRes();
        UserInfo userInfo = new UserInfo();
        String uuid=Token.getUUID();

        BeanUtils.copyProperties(user, userInfo);
        loginRes.setUserInfo(userInfo);
        loginRes.setToken(uuid);

        Token.blindUUID(user.getUsername(),uuid);
        if (!user.getPassword().equals(reqUser.getPassword())) {
            return new RespEntity(RespCode.WARN, loginRes);
        } else {
            return new RespEntity(RespCode.SUCCESS, loginRes);
        }
    }

    @ResponseBody
    @RequestMapping(value = "/register")
    //{username ; password}are required
    public RespEntity register(@RequestBody ReqUser request) {
        User user = new User();

        User tuser = userServices.getUserByUsername(request.getUsername());
        if (tuser != null)
            // if the username is already occupied, return fail
            return new RespEntity(RespCode.WARN, null);

        user.setUsername(request.getUsername());
        user.setPassword(request.getPassword());
        user.setCid("");
        user.setFaceImage("");
        user.setNickname("fker");
        user.setFaceImageBig("faker");
        user.setQrcode("nothing");

        User userResult = userServices.insertNewUser(user);
        UserHome userHome = new UserHome();
        userHome.setUserId(user.getId());
        userHome.setUsername(user.getUsername());
        userHome.setFaceImage(user.getFaceImage());
        userHome.setFaceImageBig(user.getFaceImageBig());
        userHome.setNickname(user.getNickname());
        userHome.setUserSignature("");
        userHome.setGender(-1);
        UserHome result = userServices.insertNewUserHome(userHome);
        return new RespEntity(RespCode.SUCCESS, userResult.getUsername());
    }

    @ResponseBody
    @RequestMapping("/home")
    public RespEntity home(@RequestBody ReqUser reqUser){
        User user ;
        user = userServices.getUserByUsername(reqUser.getUsername());
        UserHome userHome = new UserHome();
        if(userServices.getHomeByUserName(reqUser.getUsername()) == null) {
            userHome.setUserId(user.getId());
            userHome.setUsername(user.getUsername());
            userHome.setFaceImage(user.getFaceImage());
            userHome.setFaceImageBig(user.getFaceImageBig());
            userHome.setNickname(user.getNickname());
            userHome.setUserSignature("");
            userHome.setGender(-1);
            UserHome result = userServices.insertNewUserHome(userHome);
        }
        else{
            userHome = userServices.getHomeByUserName(reqUser.getUsername());
        }
        return new RespEntity(RespCode.SUCCESS, userHome);
    }

    @ResponseBody
    @RequestMapping("/home/setNickname")
    public RespEntity setNickname(@RequestBody ReqNickname reqNickname){
        UserHome userHome = new UserHome();
        userHome = userServices.getHomeByUserName(reqNickname.getUsername());
        userHome.setNickname(reqNickname.getNickname());
        int result = userServices.updateHomeById(userHome);
        return new RespEntity(RespCode.SUCCESS, reqNickname);
    }

    @ResponseBody
    @RequestMapping("/home/setGender")
    public RespEntity setGender(@RequestBody ReqGender reqGender){
        UserHome userHome = new UserHome();
        userHome = userServices.getHomeByUserName(reqGender.getUsername());
        if(reqGender.getGender() != 0 && reqGender.getGender() != 1){
            return new RespEntity(RespCode.WARN);
        }
        userHome.setGender(reqGender.getGender());
        int result = userServices.updateHomeById(userHome);
        return new RespEntity(RespCode.SUCCESS, result);
    }

    @ResponseBody
    @RequestMapping("/home/setSignature")
    public RespEntity setSignature(@RequestBody ReqUserSignature reqUserSignature){
        UserHome userHome = new UserHome();
        userHome = userServices.getHomeByUserName(reqUserSignature.getUsername());
        userHome.setUserSignature(reqUserSignature.getUserSignature());
        int result = userServices.updateHomeById(userHome);
        return new RespEntity(RespCode.SUCCESS, userHome);
    }

}
